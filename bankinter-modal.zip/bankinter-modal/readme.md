cookies modal:

**phone**

	# phone/home_abierto.html    line: 589
	# phone/resources/css/main.css    line: 1884
	# phone/resources/js/main.js    line: 291
	# included phone/resources/fonts folder

**tablet**

	# tablet/home_analisis.html    line: 2790
	# tablet/resources/css/main.css    line: 2323
	# tablet/resources/js/main.js    line: 550
	# included tablet/resources/fonts folder